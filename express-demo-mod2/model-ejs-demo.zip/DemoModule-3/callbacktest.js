


/*sum=(a,b,callback)=>{
callback(a+b);
}
sum(5,4,(result)=>{
    console.log(result);
});
//callback function (callbac abstraction)*/